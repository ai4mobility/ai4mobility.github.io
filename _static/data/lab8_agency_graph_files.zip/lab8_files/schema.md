# Lab 8 schema and annotation rules

The same rules are given to the person who labels the gold set and to the language model.

## Relations (12)

| relation | class | meaning | example |
|---|---|---|---|
| powers | physical | A supplies electric power to B | generator -> signal |
| services | physical | A refuels, repairs, clears or maintains B | refueling teams -> generator |
| substitutes_for | physical | A stands in for B while B is down | vacuum trucks -> lift stations |
| informs | cyber | A's data, status or document goes to B or is used by B | ATMS -> SAT |
| threatens | geographic | hazard A damages or floods B | storm surge -> lift stations |
| within | geographic | A is located inside B, or inside B's jurisdiction | North Bridge -> City of Sarasota |
| responsible_for | logical | A owns, leads, operates or performs B | Work Program -> FPID |
| supports | logical | A helps B or supplies resources to B, without owning it | RLECT -> law enforcement agencies |
| approves | logical | A approves B | FHWA -> DDIR |
| precondition_of | logical | A must happen or exist before B | State of Emergency -> emergency TWO |
| coordinates_with | logical | A and B work together (write it once, in the order the text gives) | Infrastructure Branch -> FPL |
| part_of | logical | A is grouped into B, or is a component of B | repairs -> DDIR |

## Modality (one per edge)

- required: an instruction or a must (imperative verb, "shall", "should", "to be", "must").
- recommended: "consider", "should consider".
- observed: the text reports that it happened or exists.
- failed: the text reports that the link was missing, broken or unknown.

## Rules

1. Both ends must be entities in the entity table, named on this page by one of their aliases (a plural or other small variant is fine).
2. If an SOP step names no actor, the actor is FDOT District 7 (`fdot_d7`). Use this only when the step links District 7 to a named entity (coordinate with, email to, approve).
3. When a document is sent to a team, write document -> informs -> team.
4. "Once X, do Y" and "after X, do Y" give X -> precondition_of -> Y when X and Y are both entities.
5. One edge per (subject, relation, object) on a page. The evidence is the shortest exact quote from the page (30 words at most) that supports the edge. Copy it exactly; do not paraphrase.
6. Only what this page says. No edges from general knowledge.
