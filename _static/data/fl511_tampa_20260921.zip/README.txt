FL511 Tampa Bay traffic-camera snapshots — CGN 6933 "AI for Mobility", USF
============================================================================
2949 JPEG frames, 224x224, from FDOT public FL511 CCTV cameras inside the
Tampa Bay bounding box (lat 27.50-28.35, lon -82.95 to -82.00), collected
2026-09-21 in repeated sweeps: 20260921_1753, 20260921_1819, 20260921_1844, 20260921_1910, 20260921_1935, 20260921_2001 (local Eastern time in the folder name).

labels.csv columns
  path           location inside this archive
  camera_id      FL511 camera id; the SAME camera appears in every sweep
  sweep          YYYYMMDD_HHMM, local Eastern
  src_w, src_h   native resolution before the resize to 224x224
  n_veh          vehicles found by torchvision fasterrcnn_resnet50_fpn
                 (COCO_V1 weights, score >= 0.50, COCO classes car/motorcycle/
                 bus/truck), min_size=480 on the NATIVE frame
  veh_area_frac  summed vehicle box area / frame area
  n_person       COCO 'person' detections at the same threshold
  max_score      highest vehicle score in the frame

n_veh is a MODEL'S OPINION, not ground truth. It under-counts on hazy,
defocused and long-range views and collapses after dark. Treat it as a weak
label and say so in anything you report.

Images are public FDOT traffic-camera feeds, redistributed here for classroom
use. They contain no faces or plates at this resolution. Do not use them to
identify vehicles or people.
